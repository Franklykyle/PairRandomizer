//
//  PairController.swift
//  Pair Randomizer
//
//  Created by Kyle Franklin on 8/20/21.
//

import Foundation


class PairController {
    
   
    static let shared = PairController()
    
    var pairs: [Pair] = []
    
    func createPairWith(name: String) {
        let newPair = Pair(name: name)
        pairs.append(newPair)
        saveToPersistenceStore()
    }
    
    func update(pair: Pair, name: String) {
        pair.name = name
        saveToPersistenceStore()
    }
    
    func createPersistenceStore() -> URL {
        let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let fileURL = url[0].appendingPathComponent("Pair.json")
        return fileURL
    }
    
    func saveToPersistenceStore() {
        let jsonEncoder = JSONEncoder()
        
        do {
            let data = try jsonEncoder.encode(pairs)
            try data.write(to: createPersistenceStore())
        } catch {
            print(print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)"))
        }
        
        }
    
    func loadFromPersistenceStore() {
        let jsonDecoder = JSONDecoder()
        
        do {
            let data = try Data(contentsOf: createPersistenceStore())
            pairs = try jsonDecoder.decode([Pair].self, from: data)
        } catch {
            print(print("Error in \(#function) : \(error.localizedDescription) \n---\n \(error)"))
        }
    }
    
}

