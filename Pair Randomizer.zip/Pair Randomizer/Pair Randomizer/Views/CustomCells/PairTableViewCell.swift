//
//  PairTableViewCell.swift
//  Pair Randomizer
//
//  Created by Kyle Franklin on 8/20/21.
//

import UIKit


protocol PairCompletionDelegate: AnyObject {
    
}

class PairTableViewCell: UITableViewCell {
    
    @IBOutlet weak var nameLabel1: UILabel!
    @IBOutlet weak var nameLabel2: UILabel!
    
    var pair: Pair? {
        
        didSet {
            DispatchQueue.main.async {
                self.updateViews()
            }
            
        }
        
    }
    
    weak var delegate: PairCompletionDelegate?
    
    func updateViews() {
        guard let pair = pair else { return }
        nameLabel1.text = pair.name
        nameLabel2.text = pair.name
    }
    
    
    
}
