//
//  Pair.swift
//  Pair Randomizer
//
//  Created by Kyle Franklin on 8/20/21.
//

import Foundation


class Pair: Codable {
    
    var name: String
    
    init(name: String) {
        self.name = name
        
    }
}
